# 🚀 TOON Converter - Pacchetto Pubblicazione

## 📦 Contenuto

Questo pacchetto contiene tutti i file necessari per pubblicare TOON Converter su GitHub.

### File Inclusi

- `toon-converter.html` - Applicazione principale
- `index.html` - Landing page per GitHub Pages
- `README.md` - Documentazione completa
- `LICENSE` - Licenza MIT
- `.gitignore` - File da ignorare in Git
- `CONTRIBUTING.md` - Guida per contributori
- `publish.sh` - Script di pubblicazione automatica

## 🚀 Pubblicazione Rapida

### Opzione 1: Script Automatico (più facile!)

```bash
cd toon-converter-package
chmod +x publish.sh
./publish.sh
```

Lo script ti guiderà passo-passo!

### Opzione 2: Manuale

Segui le istruzioni in `ISTRUZIONI_PUBBLICAZIONE.md`

## ✅ Email Aggiornata

✓ Tutte le email sono state aggiornate a: **privacy@prezzemolostudio.it**

## 📞 Supporto

Giuseppe, se hai problemi con la pubblicazione, dimmi e ti aiuto subito!

---

**Prezzemolo Studio - Made with ❤️ in Italy 🇮🇹**
